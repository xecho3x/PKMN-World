PokeMan Journey v0.2 - Clean Replacement Package

This version starts from the successfully tested v0.1 changes and adds the
Emerald-style interface changes planned for the second edit.

INCLUDED CHANGES
- New games begin in the Pallet Town bedroom, with Kanto active.
- Starter choices are Bulbasaur, Cyndaquil, and Mudkip.
- The rival receives the type-advantage starter.
- Early rival battles and Brock are moderately stronger.
- Gen 1-3 trade evolutions have stone-based alternatives.
- Moon Stones cost 1000 and are sold in Pewter Mart.
- Start menu uses the classic Emerald-style menu.
- Pokedex uses the standard Emerald-style interface.
- Bag uses the standard Emerald-style interface.
- Party menu uses the standard Emerald-style interface.
- Options retain the Emerald-style framework and useful project settings.

WHY THE PREVIOUS VERSION 2 DID NOT WORK
The version-2 patch was uploaded inside .github/workflows, while the active
workflow still applied pokeman-journey-v0.1.patch from the repository root.
GitHub therefore continued building version 1.

UPLOAD INSTRUCTIONS
1. Extract this ZIP on your laptop.
2. In the main page of xecho3x/PKMN-World, upload:
      pokeman-journey-current.patch
   This file must be in the repository ROOT, beside Makefile and README.md.
3. Open .github/workflows in the repository and replace:
      build-pokeman-journey.yml
   with the file from this package's .github/workflows folder.
4. Commit both uploads.
5. Open Actions > Build PokeMan Journey > Run workflow.
6. Open the finished run and download PokeMan-Journey-v0.2.
   That artifact contains pokeman_journey.gba.

IMPORTANT
- Do not upload the ZIP itself into the repository.
- Existing v0.1 files can remain; the corrected workflow uses only
  pokeman-journey-current.patch.
- A new game is recommended for reliable testing of start/story changes.

VALIDATION COMPLETED
- Version-2 patch applies cleanly to repository commit 0ca02d56.
- ValidateGen13.py passed.
- ValidateScripts.py passed.
- ValidateOwMonPlacements.py passed.
- ValidateMapEvents.py passed with only the repository's known baseline reviews.

