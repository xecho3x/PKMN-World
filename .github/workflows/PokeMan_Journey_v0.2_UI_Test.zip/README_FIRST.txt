PokeMan Journey - v0.2 UI Test

This cumulative patch keeps all v0.1 gameplay changes.

New UI test changes:
- Classic Emerald-style Start menu
- Standard Emerald-style Pokedex
- Standard Emerald-style Bag
- Standard Emerald-style Party menu
- Options screen remains the Emerald-style framework, with the project's useful extra settings still available

Not changed in this test:
- Gary starter-ball movement mismatch
- Viridian Forest nighttime brightness
- Progression beyond Brock

GitHub setup:
1. Upload pokeman-journey-current.patch to the ROOT of xecho3x/PKMN-World.
2. Replace .github/workflows/build-pokeman-journey.yml with the supplied workflow file.
   Rename build-pokeman-journey-latest.yml to build-pokeman-journey.yml when uploading.
3. Actions -> Build PokeMan Journey -> Run workflow.
4. Download artifact PokeMan-Journey-Latest.

After this setup, future versions should normally require replacing only
pokeman-journey-current.patch and running the workflow again.
