PokeMan Journey v0.1 - GitHub Build Kit

Files:
1) pokeman-journey-v0.1.patch
   - Upload this to the ROOT of your forked PKMN-World repository.

2) build-pokeman-journey.yml
   - Upload this inside .github/workflows/ in your fork.

Then open your repo's Actions tab, choose "Build PokeMan Journey", click "Run workflow",
and wait for the build to finish. Open the completed run and download the artifact named
"PokeMan-Journey-v0.1". The artifact ZIP contains pokeman_journey.gba.

Prototype changes:
- New game starts in Pallet Town.
- Bulbasaur / Cyndaquil / Mudkip starters.
- Rival gets the type-advantage starter.
- Early rival and Brock are moderately stronger.
- Gen 1-3 trade evolutions get stone-based alternatives, mainly Moon Stone.
- Moon Stones are sold in Pewter Mart for 1000.
- Existing modern physical/special and field-move QoL from PKMN-World remain enabled.
